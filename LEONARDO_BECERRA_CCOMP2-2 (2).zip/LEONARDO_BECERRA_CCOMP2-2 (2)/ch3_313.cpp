#include <iostream>
#include "ch3_313.h"
using namespace std;
int main()
{
Account account1{"Jane Green", 50};
Account account2{"John Blue", -7};

account1.print();


}